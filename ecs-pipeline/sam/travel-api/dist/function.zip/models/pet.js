"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Pet = void 0;
/**
 * A Pet
 */
class Pet {
    constructor(id, type, price, owner, ownerDisplayName) {
        this.id = id;
        this.type = type;
        this.price = price;
        this.owner = owner;
        this.ownerDisplayName = ownerDisplayName;
    }
}
exports.Pet = Pet;
