"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DynamoDBStorageService = void 0;
const aws = require("aws-sdk");
class DynamoDBStorageService {
    constructor(tableName, docClient = new aws.DynamoDB.DocumentClient()) {
        this.tableName = tableName;
        this.docClient = docClient;
    }
    async getPet(id) {
        try {
            const data = await this.docClient.get({
                TableName: this.tableName,
                Key: { id },
                ConsistentRead: true,
            }).promise();
            if (data && data.Item) {
                return data.Item;
            }
            return null; // return null vs undefined
        }
        catch (ex) { // AWSError
            console.warn("Error getting entry", ex);
            throw ex;
        }
    }
    async savePet(pet) {
        try {
            await this.docClient.put({
                TableName: this.tableName,
                Item: pet,
            }).promise();
        }
        catch (ex) {
            console.warn("Error saving entry", ex);
            throw ex;
        }
    }
    async getAllPets() {
        try {
            const result = [];
            const params = { TableName: this.tableName };
            while (true) {
                const data = await this.docClient.scan(params).promise();
                result.push(...data.Items);
                if (!data.LastEvaluatedKey) {
                    break;
                }
                params.ExclusiveStartKey = data.LastEvaluatedKey;
            }
            return result;
        }
        catch (ex) { // AWSError
            console.warn("Error getting all entries", ex);
            throw ex;
        }
    }
    async deletePet(id) {
        try {
            await this.docClient.delete({ TableName: this.tableName, Key: { id } }).promise();
        }
        catch (ex) {
            console.warn("Error deleting entry", ex);
            throw ex;
        }
    }
    async getAllPetsByOwner(owner) {
        // in a real world scenario this will be probably using a query on a global secondary index (owner)
        // for simplicity of the demo, this will just filter the scanned results
        return (await this.getAllPets()).filter((pet) => pet.owner === owner);
    }
}
exports.DynamoDBStorageService = DynamoDBStorageService;
