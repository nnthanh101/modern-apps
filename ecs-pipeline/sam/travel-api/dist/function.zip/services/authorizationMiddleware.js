"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.authorizationMiddleware = void 0;
/**
 * Returns the groups claim from either the id or access tokens as a Set
 * @param claims
 */
const getGroups = (claims) => {
    const groups = claims["cognito:groups"];
    if (groups) {
        return new Set(groups);
    }
    return new Set();
};
/**
 * Parses the token and returns the claims
 * @param token a base64 encoded JWT token (id or access)
 * @return parsed Claims or null if no token was provided
 */
const getClaimsFromToken = (token) => {
    if (!token) {
        return null;
    }
    try {
        const base64decoded = Buffer.from(token.split(".")[1], "base64").toString("ascii");
        return JSON.parse(base64decoded);
    }
    catch (e) {
        console.error("Invalid JWT token", e);
        // in case a malformed token was provided, we treat it as if non was provided, users will get a 401 in our case
        return null;
    }
};
/**
 * Creates a middleware that enriches the request object with:
 * - claims: Claims (JWT ID token claims)
 * - groups: Set<string> (Cognito User Pool Groups, from the cognito:groups claim)
 *
 * It will return a 403 if non of the supportedGroups exists in the claim
 *
 * @param opts
 *
 */
exports.authorizationMiddleware = (opts) => async (req, res, next) => {
    if (opts && opts.allowedPaths && opts.allowedPaths.includes(req.path)) {
        next();
        return;
    }
    const authorizationHeaderName = opts && opts.authorizationHeaderName || "Authorization";
    const token = req.header(authorizationHeaderName);
    const claims = getClaimsFromToken(token);
    if (claims) {
        req.claims = claims;
        if (claims["cognito:username"]) {
            // username claim name in the id token
            req.username = claims["cognito:username"];
        }
        else if (claims.username) {
            // username claim name in the access token
            req.username = claims.username;
        }
        else {
            console.warn(`No username claim found in token, using sub as username`);
            req.username = claims.sub;
        }
        // always returns a Set, if no groups, it will be empty.
        const groups = getGroups(claims);
        req.groups = groups;
        // check if the user has at least 1 required group
        // e.g. if the claim has [g1]
        // and basicGroups includes [g1, g2]
        // it means the user has at least one of the groups that allows them to do something
        if (opts && opts.supportedGroups) {
            const userHasAtLeastOneSupportedGroup = opts.supportedGroups.some((g) => groups.has(g));
            if (!userHasAtLeastOneSupportedGroup) {
                res.status(403).json({ error: "Unauthorized" });
                return;
            }
        }
        // check if user did a global sign out (optional)
        if (opts && opts.forceSignOutHandler) {
            const isTokenRevoked = await opts.forceSignOutHandler.isForcedSignOut(req);
            if (isTokenRevoked) {
                res.status(401).json({ error: "Your session has expired, please sign in again" });
                return;
            }
        }
        // if we got here, continue with the request
        next();
    }
    else {
        // the only way to get here (e.g. no claims on the request) is if it's on a path with no required auth
        // or if the token header name is incorrect
        // API Gateway would deny access otherwise
        // but for defense in depth, we return an explicit deny here (e.g. in case of running locally)
        res.status(401).json({ error: "Please sign in" });
    }
};
